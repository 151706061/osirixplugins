//-----------------------------------------------------------------------------
// AS_StorageDevice_Raw.h
// Copyright (c) Corel Corporation or its subsidiaries. All rights reserved.
//-----------------------------------------------------------------------------

///////////////////////////////////////////////////////////////////////////////
// AS_StorageDevice_Raw allows for the reading and writing of raw blocks
// from/to supported media.
///////////////////////////////////////////////////////////////////////////////

#ifndef __AS_StorageDevice_Raw_h__
#define __AS_StorageDevice_Raw_h__

#include "AS_StorageDevice.h"


#ifdef __cplusplus
extern "C"
{
#endif


struct AS_StorageDevice_Raw
{
	// Properties for use in writing an image. See AS_StorageDevice_WriteImage.
	enum Image_Type          // Type          Description
	{
		Image_ISO       = 1, // ISO           Standard 1 track 2048-byte-per-block image
		Image_MovieDisc = 2, // MovieDisc     Can be 2048-bytes-per-block or 2054, XML specifies parameters
		Image_CopyBlock = 4, // CopyBlock     2048 bytes-per-block, bad blocks marked according to CopyBlock spec
	};

	// Optional flags for AS_StorageDevice_WriteImage
	static const UInt32 WriteImageFlags_None   = 0;
	static const UInt32 WriteImageFlags_Verify = 1;

	// DEPRECATED
	typedef UInt32 RawCopyFlags; // DEPRECATED: CopyFlags in AS_StorageDevice.h should be used instead
	static const RawCopyFlags RawCopyFlags_None      = (1 << 0);
	static const RawCopyFlags RawCopyFlags_ISO       = (1 << 1);
	static const RawCopyFlags RawCopyFlags_GI        = (1 << 2);
	static const RawCopyFlags RawCopyFlags_MovieDisc = (1 << 8);
	static const RawCopyFlags RawCopyFlags_CopyBlock = (1 << 9);

	enum PrepareMode
	{
		PrepareMode_None            = 0, // Disable streaming bit for writes
		PrepareMode_Write_Streaming = 1  // Enable Streaming bit for writes
	};

	typedef UInt32 OpenRawMode;
	static const OpenRawMode OpenRawMode_Exclusive    = 1;          // Exclusive access to media - prevent others from access
	static const OpenRawMode OpenRawMode_ReadWrite    = 2;          // Open media in read/write mode
	static const OpenRawMode OpenRawMode_Read         = 3;          // Open media in read only mode
	static const OpenRawMode OpenRawMode_ForceRefresh = 0x80000000; // Force refresh (used mostly for copy operations)

	// Optional flags for raw reads. See AS_StorageDevice_(Get/Set)ReadFlags.
	typedef UInt32 ReadFlags;
	static const ReadFlags ReadFlags_None = 0;        // Default: No optional read flags are set
	static const ReadFlags ReadFlags_DAP  = (1 << 0); // CD-DA Only: Digital Audio Playback (DAP)

	enum WriteMode
	{
		WriteMode_RestrictedOverwrite = 1,
		WriteMode_Packet              = 2
	};

	typedef UInt32 Access_Type;
	static const Access_Type Access_Sync  = 0; // Access device for synchronous direct access
	static const Access_Type Access_Async = 1; // Access device for asynchronous job access

	typedef UInt32 SendCommand_Flags;
	static const SendCommand_Flags SendCommand_DataIn  = 1;
	static const SendCommand_Flags SendCommand_DataOut = 2;

	typedef UInt32 EncryptionModes;
	static const EncryptionModes Encrypt_None          = 0x0000;
	static const EncryptionModes Encrypt_SecureData    = 0x0001;
	static const EncryptionModes Encrypt_SecureCBC     = 0x0002; // DEPRECATED
	static const EncryptionModes Encrypt_SecureArchive = 0x0010; // Reserved for future use
	static const EncryptionModes Encrypt_Patronus      = 0x0100; // Reserved for future use
};

//-----------------------------------------------------------------------------
// AS_StorageDevice_Raw API Functions
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// AS_StorageDevice_OpenRawAccess
//
// DESCRIPTION:
// Open an AS_StorageDevice device for raw access.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if 'device' is invalid
//  AS_StorageError_InvalidHandle    - if an error occurs while opening a file device (AS_StorageDevice::Type_File)
//  AS_StorageError_DeviceError      - if an error occurs while opening
//  AS_StorageError_DeviceNotReady   - if the device is not ready
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//
AS_StorageError AS_API AS_StorageDevice_OpenRawAccess(
	AS_StorageDevice& device,                          // IN: Device reference
	AS_StorageDevice_Raw::OpenRawMode openMode,        // IN: Mode to open device in (read/readwrite/exclusive)
	AS_StorageDevice_Raw::Access_Type accessType);     // IN: Access type for device (sync/async)

//-----------------------------------------------------------------------------
// AS_StorageDevice_CloseRawAccess
//
// DESCRIPTION:
// Close the specified device that was opened for raw access.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if 'device' is invalid
//  AS_StorageError_DeviceError      - if an error occurs while closing
//  AS_StorageError_DeviceNotReady   - if the device is not ready
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//
AS_StorageError AS_API AS_StorageDevice_CloseRawAccess(
	const AS_StorageDevice& device,                     // IN: Device reference
	AS_StorageDevice::InfoCallback callback,            // IN: Progress callback function
	void* userData);                                   // IN: Progress callback user data

//-----------------------------------------------------------------------------
// AS_StorageDevice_SetMode
//
// DESCRIPTION:
// Set the write mode of the specified device.
//
// NOTES:
// Only WriteMode_RestrictedOverwrite is supported at this time.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if 'device' is invalid
//  AS_StorageError_NotImplemented   - if 'mode' is not yet supported
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//
AS_StorageError AS_API AS_StorageDevice_SetMode(
	const AS_StorageDevice& device,              // IN: Device reference
	AS_StorageDevice_Raw::WriteMode mode);       // IN: Write mode for raw access

//-----------------------------------------------------------------------------
// AS_StorageDevice_GetMode
//
// DESCRIPTION:
// Get the write mode of the specified device.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if 'device' is invalid
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//
AS_StorageError AS_API AS_StorageDevice_GetMode(
	const AS_StorageDevice& device,              // IN: Device reference
	AS_StorageDevice_Raw::WriteMode& mode);      // OUT: Current write mode

//-----------------------------------------------------------------------------
// AS_StorageDevice_SetReadMode
//
// DESCRIPTION:
// Set the read mode of the specified device.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if 'device' is invalid
//  AS_StorageError_DeviceNotReady   - if the device is not ready
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//
AS_StorageError AS_API AS_StorageDevice_SetReadFlags(
	const AS_StorageDevice& device,                   // IN: Device reference
	AS_StorageDevice_Raw::ReadFlags flags);           // IN: Read flags for raw reads

//-----------------------------------------------------------------------------
// AS_StorageDevice_GetReadMode
//
// DESCRIPTION:
// Get the read mode of the specified device.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if 'device' is invalid
//  AS_StorageError_DeviceNotReady   - if the device is not ready
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//
AS_StorageError AS_API AS_StorageDevice_GetReadFlags(
	const AS_StorageDevice& device,                   // IN: Device reference
	AS_StorageDevice_Raw::ReadFlags& flags);          // OUT: Current read flags

//-----------------------------------------------------------------------------
// AS_StorageDevice_Read
//
// DESCRIPTION:
// Perform a raw device read using the specified device.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if 'device' is invalid
//  AS_StorageError_DeviceError      - if a read error occurs
//  AS_StorageError_DeviceNotReady   - if the device is not ready
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//
AS_StorageError AS_API AS_StorageDevice_Read(
	const AS_StorageDevice& device,           // IN: Device reference
	UInt32 blkNum,                            // IN: Block offset on media
	UInt32 bufLen,                            // IN: Number of sectors to read
	void* buf,                                // OUT: Buffer to hold the data read
	UInt32* numRead);                         // OUT: Number of sectors read

//-----------------------------------------------------------------------------
// AS_StorageDevice_Write
//
// DESCRIPTION:
// Perform a raw device write using the specified device.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if 'device' is invalid
//  AS_StorageError_DeviceError      - if a write error occurs
//  AS_StorageError_DeviceNotReady   - if the device is not ready
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//
AS_StorageError AS_API AS_StorageDevice_Write(
	const AS_StorageDevice& device,            // IN: Device reference
	UInt32 blkNum,                             // IN: Block offset on media
	UInt32 bufLen,                             // IN: Number of sectors to write
	void* buf,                                 // IN: Buffer holding data to write
	UInt32* numWritten);                       // OUT: Number of sectors written

//-----------------------------------------------------------------------------
// AS_StorageDevice_WriteImage
//
// DEPRECATED:
// This method has been deprecated and is superseded by AS_StorageDevice_Copy.
//
// DESCRIPTION:
// Write an image file to device. The device state must be ready.
//
// NOTES:
// Only AS_StorageDevice_Raw::Image_ISO is supported at this time.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if 'device' is invalid
//  AS_StorageError_DeviceError      - if a write error occurs
//  AS_StorageError_DeviceNotReady   - if the device is not ready
//  AS_StorageError_NotImplemented   - if 'imageType' is not yet supported
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//
AS_StorageError AS_API AS_StorageDevice_WriteImage(
	const AS_StorageDevice& device,                  // IN: Device reference
	AS_StorageDevice_Raw::Image_Type imageType,      // IN: Type of image (Image_ISO, etc.)
	UInt32 flags,                                    // IN: Flags (0)
	AS_String filepath,                              // IN: Path to image file
	AS_StorageDevice::InfoCallback callback,         // IN: Progress callback function
	void* userData);                                // IN: Progress callback user data

//-----------------------------------------------------------------------------
// AS_StorageDevice_GetBuffer
//
// DESCRIPTION:
// Get buffer from engine for the specified device. If none is available,
// the method will block.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if 'device' is invalid
//  AS_StorageError_DeviceError      - if the buffer could not be obtained
//  AS_StorageError_DeviceNotReady   - if the device is not ready
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//
AS_StorageError AS_API AS_StorageDevice_GetBuffer(
	const AS_StorageDevice& device,                // IN: Device reference
	void** buf);                                   // OUT: Pointer to the buffer

//-----------------------------------------------------------------------------
// AS_StorageDevice_PrepareWrite
//
// DESCRIPTION:
// Enable or disable the streaming bit for writing.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if 'device' is invalid
//  AS_StorageError_DeviceNotReady   - if the device is not ready
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//
AS_StorageError AS_API AS_StorageDevice_PrepareWrite(
	const AS_StorageDevice& device,                   // IN: Device reference
	AS_StorageDevice_Raw::PrepareMode mode);          // IN: Prepare flags

//-----------------------------------------------------------------------------
// AS_StorageDevice_ReadAsync
//
// DESCRIPTION:
// Read blocks from the specified device asyncronously.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if 'device' is invalid
//  AS_StorageError_DeviceError      - if 'bufLen' sectors were not read
//  AS_StorageError_DeviceNotReady   - if the device is not ready
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//
AS_StorageError AS_API AS_StorageDevice_ReadAsync(
	const AS_StorageDevice& device,                // IN: Source device
	UInt32 blkNum,                                 // IN: Block offset on media
	UInt32 bufLen,                                 // IN: Number of sectors to read
	void* buf,                                     // OUT: Buffer to hold the data read
	UInt32* numRead);                              // OUT: Number of sectors read

//-----------------------------------------------------------------------------
// AS_StorageDevice_WriteAsync
//
// DESCRIPTION:
// Write blocks to the specified device asyncronously.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if 'device' is invalid
//  AS_StorageError_DeviceError      - if the write failed or did not write 'bufLen' sectors
//  AS_StorageError_DeviceNotReady   - if the device is not ready
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//
AS_StorageError AS_API AS_StorageDevice_WriteAsync(
	const AS_StorageDevice& device,                 // IN: Destination device
	UInt32 blkNum,                                  // IN: Block offset on media
	UInt32 bufLen,                                  // IN: Number of sectors to write
	void* buf,                                      // OUT: Buffer holding the data to write
	UInt32* numWritten,                             // OUT: Number of sectors written
	UInt32* complete);                              // OUT: Reserved for future use - Non-zero if the write has completed

//-----------------------------------------------------------------------------
// AS_StorageDevice_SendCommand
//
// DESCRIPTION:
// Send raw CDBs to the specified device.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if 'device' is invalid
//  AS_StorageError_DeviceError      - if a check condition occurs
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//
AS_StorageError AS_API AS_StorageDevice_SendCommand(
	const AS_StorageDevice& device,                  // IN: Device reference
	UInt32 dwCmdLen,                                 // IN: Length of the command bytes below
	UInt8* pCmd,                                     // IN: Pointer to the CDB buffer
	UInt32 dwDataLen,                                // IN: Size of the data buffer in bytes
	UInt8* pData,                                    // IN: Pointer to the data buffer
	AS_StorageDevice_Raw::SendCommand_Flags flags,   // IN: Flags for the command
	UInt32 dwTimeOut,                                // IN: Timeout value for the command
	UInt32 dwSenseBufSize,                           // IN: Size of sense information buffer in bytes
	UInt8* pdwSense,                                 // OUT: Sense error information if an error occurred
	UInt32* pdwASC,                                  // OUT: Sense code
	UInt32* pdwASCQ);                                // OUT: Sense qualifier

//-----------------------------------------------------------------------------
// AS_StorageDevice_EncryptSource
//
// DESCRIPTION:
// Encrypt a source image specified by 'srcPath' to 'dstPath' using the
// selected encryption mode (AS_StorageDevice_Raw::EncryptionModes).
//
// NOTES:
// Only AS_StorageDevice::FormatType_ISO_SecureData is supported at this time.
//
// RETURN:
//  AS_StorageError_None             - ok
//  AS_StorageError_InvalidParameter - if the source or destination path is invalid
//  AS_StorageError_NotImplemented   - if 'dstFormat' is not yet supported
//  AS_StorageError_Fatal            - if an unknown or unrecognized error occurs
//
AS_StorageError AS_API AS_StorageDevice_EncryptSource(
	const AS_StorageDevice& srcPath,                   // IN: Source ISO filepath of the image to use
	const AS_StorageDevice& dstPath,                   // IN: Destination path for the encrypted file/container
	AS_String keyPath,                                 // IN: KeyPath of public key used to encrypt
	AS_StorageDevice::FileFormatType dstFormat,        // IN: Destination file format type (FormatType_ISO_SecureData, etc.)
	AS_StorageDevice_Raw::EncryptionModes encMode,     // IN: Destination encryption mode (Encrypt_SecureData, etc.)
	UInt32 customerNumber,                             // IN: Customer number for AES VOB encrypted; Provider number for secure archive; Undefined for other protections at this time
	UInt32 bufferSize,                                 // IN: Reserved for future use
	void* buffer,                                      // IN/OUT: Reserved for future use
	UInt32* retSize,                                   // OUT: Reserved for future use - Return size if buffer is OUT
	AS_StorageDevice::InfoCallback callback,           // IN: Progress callback function
	void* userData);                                  // IN: Progress callback user data


#ifdef __cplusplus
}
#endif

#endif //__AS_StorageDevice_Raw_h__
