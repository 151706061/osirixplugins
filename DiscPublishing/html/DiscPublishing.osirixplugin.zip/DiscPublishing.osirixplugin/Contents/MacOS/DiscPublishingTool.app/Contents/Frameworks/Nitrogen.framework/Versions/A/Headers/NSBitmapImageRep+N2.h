/*=========================================================================
  Program:   OsiriX

  Copyright (c) OsiriX Team
  All rights reserved.
  Distributed under GNU - LGPL
  
  See http://www.osirix-viewer.com/copyright.html for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.
=========================================================================*/

#import <Cocoa/Cocoa.h>


@interface NSBitmapImageRep (N2)

-(void)setColor:(NSColor*)color;
-(NSImage*)image;
-(NSBitmapImageRep*)repUsingColorSpaceName:(NSString*)colorSpaceName;

-(void)ATMask:(float)level DEPRECATED_ATTRIBUTE;
-(NSBitmapImageRep*)smoothen:(NSUInteger)margin;
//-(NSBitmapImageRep*)convolveWithFilter:(const boost::numeric::ublas::matrix<float>&)filter fillPixel:(NSUInteger[])fillPixel;
//-(NSBitmapImageRep*)fftConvolveWithFilter:(const boost::numeric::ublas::matrix<float>&)filter fillPixel:(NSUInteger[])fillPixel;

@end
